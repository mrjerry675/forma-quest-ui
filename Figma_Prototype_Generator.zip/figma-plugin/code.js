"use strict";
/// <reference types="@figma/plugin-typings" />
const C = { ink: '#24332D', muted: '#78857E', line: '#E4EAE5', bg: '#F7F8FA', white: '#FFFFFF', green: '#176B56', greenSoft: '#EAF3EE', purple: '#7553D8', purpleSoft: '#F0EBFB', gold: '#B68A34' };
const color = (hex) => ({ r: parseInt(hex.slice(1, 3), 16) / 255, g: parseInt(hex.slice(3, 5), 16) / 255, b: parseInt(hex.slice(5, 7), 16) / 255 });
const fill = (hex) => ({ type: 'SOLID', color: color(hex) });
const primary = (p) => p === 'Forma' ? C.green : C.purple;
const soft = (p) => p === 'Forma' ? C.greenSoft : C.purpleSoft;
let font = 'Inter';
let page;
const roots = {};
const routes = [];
const components = {};
const transition = { type: 'SMART_ANIMATE', easing: { type: 'EASE_OUT' }, duration: .3 };
function txt(value, size = 14, weight = 'Regular', ink = C.ink, width) {
    const t = figma.createText();
    t.name = value.slice(0, 55);
    t.fontName = { family: font, style: weight === 'Semi Bold' ? 'Semi Bold' : weight };
    t.fontSize = size;
    t.characters = value;
    t.fills = [fill(ink)];
    t.lineHeight = { unit: 'PERCENT', value: 145 };
    if (width) {
        t.resize(width, Math.max(size * 1.45, t.height));
        t.textAutoResize = 'HEIGHT';
    }
    else
        t.textAutoResize = 'WIDTH_AND_HEIGHT';
    return t;
}
function frame(name, width, mode = 'VERTICAL', bg, pad = 0, gap = 12, height) {
    const f = figma.createFrame();
    f.name = name;
    f.resize(width, height || 1);
    f.layoutMode = mode;
    f.primaryAxisSizingMode = mode === 'HORIZONTAL' ? 'FIXED' : height ? 'FIXED' : 'AUTO';
    f.counterAxisSizingMode = mode === 'HORIZONTAL' && !height ? 'AUTO' : 'FIXED';
    f.itemSpacing = gap;
    f.paddingLeft = f.paddingRight = f.paddingTop = f.paddingBottom = pad;
    f.fills = bg ? [fill(bg)] : [];
    f.clipsContent = false;
    return f;
}
function add(parent, ...children) { children.forEach(c => parent.appendChild(c)); return parent; }
function row(name, width, children, gap = 12) { return add(frame(name, width, 'HORIZONTAL', undefined, 0, gap), ...children); }
function card(name, width, bg = C.white, pad = 22, gap = 14) { const f = frame(name, width, 'VERTICAL', bg, pad, gap); f.cornerRadius = 15; f.strokes = [fill(C.line)]; f.strokeWeight = 1; return f; }
function spacer(width, height) { return frame('Space', width, 'VERTICAL', undefined, 0, 0, height); }
function rule(width) { const n = figma.createRectangle(); n.name = 'Divider'; n.resize(width, 1); n.fills = [fill(C.line)]; return n; }
function pill(label, p = 'Forma', width) { const t = txt(label, 11, 'Semi Bold', primary(p)); const f = frame('Status / ' + label, width || t.width + 18, 'HORIZONTAL', soft(p), 8, 0); f.paddingTop = f.paddingBottom = 5; f.cornerRadius = 6; add(f, t); return f; }
function bind(node, to) { routes.push({ node, to }); return node; }
function progress(width, amount, p) { const f = frame('Progress track', width, 'HORIZONTAL', '#E9ECEB', 0, 0, 6); f.cornerRadius = 5; const n = figma.createRectangle(); n.name = 'Progress fill'; n.resize(Math.max(1, width * amount), 6); n.cornerRadius = 5; n.fills = [fill(primary(p))]; add(f, n); return f; }
function button(label, p, to, secondary = false, width) {
    const instance = components[`${p}/${secondary ? 'Secondary' : 'Primary'}/Default`].createInstance();
    instance.name = 'Button / ' + label;
    const labelNode = instance.findOne(n => n.type === 'TEXT');
    labelNode.characters = label;
    if (width) {
        instance.resize(width, 44);
        instance.primaryAxisSizingMode = 'FIXED';
    }
    if (to)
        bind(instance, to);
    return instance;
}
function field(label, value, width, large = false) {
    const f = frame('Field / ' + label, width);
    const input = components[`Input/${large ? 'Multiline' : 'Default'}`].createInstance();
    input.resize(width, large ? 80 : 44);
    input.primaryAxisSizingMode = 'FIXED';
    input.counterAxisSizingMode = 'FIXED';
    const text = input.findOne(n => n.type === 'TEXT');
    text.characters = value;
    text.resize(width - 24, large ? 51 : 20);
    text.textAutoResize = 'HEIGHT';
    add(f, txt(label, 12, 'Semi Bold', '#53645A'), input);
    return f;
}
function avatar(label, bg = C.greenSoft) { const f = frame('Avatar', 34, 'HORIZONTAL', bg, 0, 0, 34); f.cornerRadius = 17; f.primaryAxisAlignItems = 'CENTER'; f.counterAxisAlignItems = 'CENTER'; add(f, txt(label, 11, 'Bold', '#677B6B')); return f; }
function navItem(label, p, active, to) { const f = frame('Navigation / ' + label, 188, 'HORIZONTAL', active ? soft(p) : undefined, 12, 10, 44); f.cornerRadius = 9; f.counterAxisAlignItems = 'CENTER'; add(f, txt(label, 13, active ? 'Semi Bold' : 'Regular', active ? primary(p) : C.muted)); return bind(f, to); }
function shell(id, title, sub, p, navIndex = 0) {
    const root = frame(id, 1440, 'HORIZONTAL', C.bg, 0, 0, 1440);
    root.clipsContent = true;
    page.appendChild(root);
    roots[id] = root;
    const sidebar = frame('Sidebar', 224, 'VERTICAL', C.white, 18, 9, 1440);
    sidebar.paddingTop = 30;
    sidebar.strokes = [fill(C.line)];
    const brand = row('Brand', 188, [txt(p === 'Forma' ? 'f' : '✦', 28, 'Bold', primary(p)), txt(p.toLowerCase(), 26, 'Bold', C.ink)], 10);
    add(sidebar, brand, spacer(188, 26), txt(p === 'Forma' ? 'YOUR NEXT CHAPTER' : 'MAKE ROOM TO GROW', 10, 'Semi Bold', '#8B9790'), spacer(188, 7));
    const menu = p === 'Forma' ? [['1  Your profile', 'R1'], ['2  Choose a template', 'R2'], ['3  AI suggestions', 'R4'], ['4  Review & export', 'R6']] : [['Overview', 'L1'], ['My learning', 'L2'], ['Leaderboard', 'L6'], ['Achievements', 'L7']];
    menu.forEach(([label, to], i) => add(sidebar, navItem(label, p, i === navIndex, to)));
    const space = spacer(188, 1);
    space.layoutGrow = 1;
    add(sidebar, space);
    const note = card('Progress note', 188, soft(p), 14, 9);
    add(note, txt(p === 'Forma' ? 'A little clarity goes a long way.' : 'Level 4 explorer', 12, 'Semi Bold', C.ink, 160), txt(p === 'Forma' ? 'Your profile is 100% complete.' : '320 XP to your next level', 11, 'Regular', C.muted, 160), progress(160, p === 'Forma' ? 1 : .2, p));
    add(sidebar, note, spacer(188, 10), rule(188), row('Workspace user', 188, [avatar('AK', soft(p)), add(frame('User details', 138, 'VERTICAL', undefined, 0, 2), txt('Ayesha Khan', 12, 'Semi Bold'), txt('Personal workspace', 10, 'Regular', C.muted))], 10));
    const area = frame('Workspace', 1216, 'VERTICAL', undefined, 0, 0, 1440);
    const top = frame('Top bar', 1216, 'HORIZONTAL', C.white, 30, 10, 76);
    top.paddingTop = top.paddingBottom = 20;
    top.counterAxisAlignItems = 'CENTER';
    const crumb = txt(p === 'Forma' ? 'Workspace   /   My resume' : 'Search your next adventure…', 12, 'Regular', C.muted, 880);
    add(top, crumb, pill(p === 'Forma' ? 'Saved on this device' : '6 day streak', p), avatar('AK', soft(p)));
    const main = frame('Main', 1216, 'VERTICAL', undefined, 32, 24);
    const heading = frame('Page heading', 1152, 'VERTICAL', undefined, 0, 6);
    add(heading, txt(title, 32, 'Semi Bold', C.ink, 1152), txt(sub, 13, 'Regular', C.muted, 1152));
    add(main, heading);
    add(area, top, main);
    add(root, sidebar, area);
    return { main, root };
}
async function makeComponents() {
    const masters = [];
    for (const p of ['Forma', 'Quest'])
        for (const style of ['Primary', 'Secondary'])
            for (const state of ['Default', 'Hover', 'Disabled']) {
                const f = frame('Button seed', 180, 'HORIZONTAL', style === 'Primary' ? (state === 'Hover' ? (p === 'Forma' ? '#10533F' : '#5E3CC0') : primary(p)) : C.white, 16, 8, 44);
                f.paddingTop = f.paddingBottom = 11;
                f.primaryAxisSizingMode = 'AUTO';
                f.counterAxisAlignItems = 'CENTER';
                f.primaryAxisAlignItems = 'CENTER';
                f.cornerRadius = 9;
                if (style === 'Secondary')
                    f.strokes = [fill(C.line)];
                if (state === 'Disabled')
                    f.opacity = .45;
                add(f, txt('Continue →', 13, 'Semi Bold', style === 'Primary' ? C.white : C.ink));
                const c = figma.createComponentFromNode(f);
                c.name = `Product=${p}, Style=${style}, State=${state}`;
                c.description = 'Reusable Auto Layout button. Change text in the instance; variants provide state and visual hierarchy.';
                components[`${p}/${style}/${state}`] = c;
                masters.push(c);
            }
    const set = figma.combineAsVariants(masters, page);
    set.name = 'Components / Button';
    set.x = 0;
    set.y = -650;
    set.layoutMode = 'HORIZONTAL';
    set.layoutWrap = 'WRAP';
    set.resize(1150, 230);
    set.primaryAxisSizingMode = 'FIXED';
    set.counterAxisSizingMode = 'AUTO';
    set.itemSpacing = 18;
    set.counterAxisSpacing = 18;
    set.paddingLeft = set.paddingRight = set.paddingTop = set.paddingBottom = 20;
    set.fills = [fill('#F4F4F7')];
    for (const p of ['Forma', 'Quest'])
        for (const style of ['Primary', 'Secondary']) {
            await components[`${p}/${style}/Default`].setReactionsAsync([{ trigger: { type: 'ON_HOVER' }, actions: [{ type: 'NODE', destinationId: components[`${p}/${style}/Hover`].id, navigation: 'CHANGE_TO', transition }] }]);
        }
    const inputs = [];
    for (const state of ['Default', 'Focus', 'Error', 'Multiline']) {
        const f = frame('Input seed', 248, 'HORIZONTAL', C.white, 12, 0, state === 'Multiline' ? 80 : 44);
        f.paddingTop = f.paddingBottom = 10;
        f.cornerRadius = 8;
        f.strokes = [fill(state === 'Focus' ? C.green : state === 'Error' ? '#B64A3D' : C.line)];
        f.strokeWeight = state === 'Focus' ? 2 : 1;
        add(f, txt('Editable value', 13, 'Regular', '#4A5E50', 224));
        const c = figma.createComponentFromNode(f);
        c.name = 'State=' + state;
        components['Input/' + state] = c;
        inputs.push(c);
    }
    const inputSet = figma.combineAsVariants(inputs, page);
    inputSet.name = 'Components / Input';
    inputSet.x = 0;
    inputSet.y = -340;
    inputSet.layoutMode = 'HORIZONTAL';
    inputSet.itemSpacing = 20;
    inputSet.primaryAxisSizingMode = 'AUTO';
    inputSet.counterAxisSizingMode = 'AUTO';
    inputSet.paddingLeft = inputSet.paddingRight = inputSet.paddingTop = inputSet.paddingBottom = 20;
    const badges = [];
    for (const state of ['Unlocked', 'Locked']) {
        const f = card('Badge seed', 160, state === 'Unlocked' ? C.purpleSoft : '#F0F1F4', 20, 8);
        f.counterAxisAlignItems = 'CENTER';
        add(f, txt(state === 'Unlocked' ? '✦' : '○', 30, 'Bold', state === 'Unlocked' ? C.purple : '#ABB0B9'), txt('Week warrior', 12, 'Semi Bold'));
        const c = figma.createComponentFromNode(f);
        c.name = 'State=' + state;
        components['Badge/' + state] = c;
        badges.push(c);
    }
    const badgeSet = figma.combineAsVariants(badges, page);
    badgeSet.name = 'Components / Achievement badge';
    badgeSet.x = 1150;
    badgeSet.y = -650;
    badgeSet.layoutMode = 'HORIZONTAL';
    badgeSet.itemSpacing = 20;
    badgeSet.primaryAxisSizingMode = 'AUTO';
    badgeSet.counterAxisSizingMode = 'AUTO';
    const intro = frame('Design foundations', 650, 'VERTICAL', C.white, 24, 12);
    intro.x = 1530;
    intro.y = -650;
    add(intro, txt('Forma + Quest / Design foundations', 24, 'Semi Bold'), txt('Native Auto Layout • Editable text • Component variants • Smart Animate', 13, 'Regular', C.muted, 602), txt('Spacing: 4 / 8 / 12 / 16 / 24 / 32\nType: Inter 11 / 13 / 16 / 20 / 32\nCorners: 8 / 12 / 16\nMotion: 300ms Ease out', 14, 'Regular', C.muted, 602), row('Brand colors', 602, [pill('Forma #176B56', 'Forma'), pill('Quest #7553D8', 'Quest')], 16));
    page.appendChild(intro);
}
function resumePreview(template = 'Evergreen', applied = false) {
    const column = frame('Live preview', 568, 'VERTICAL', undefined, 0, 12);
    add(column, row('Preview header', 568, [txt('◉  Live preview', 12, 'Semi Bold', C.muted, 382), pill(template + ' · A4', 'Forma')], 12));
    const stage = card('Preview canvas', 568, '#E9EEEA', 20, 0);
    const paper = frame('Resume document', 528, 'VERTICAL', C.white, 32, 15, 710);
    if (template === 'Evergreen') {
        paper.strokes = [fill(C.green)];
        paper.strokeTopWeight = 5;
        paper.strokeBottomWeight = paper.strokeLeftWeight = paper.strokeRightWeight = 0;
    }
    if (template === 'Studio') {
        paper.strokes = [fill('#48658C')];
        paper.strokeLeftWeight = 12;
        paper.strokeTopWeight = paper.strokeBottomWeight = paper.strokeRightWeight = 0;
    }
    add(paper, txt('Ayesha Khan', 29, 'Semi Bold', template === 'Editorial' ? C.ink : C.green, 464), txt('Product Designer', 13, 'Regular', C.muted, 464), txt('ayesha.khan@example.com  ·  Lahore, Pakistan', 10, 'Regular', C.muted, 464), rule(464), txt('PROFILE', 10, 'Bold', C.green), txt(applied ? 'Product Designer with skills in Figma, user research, and prototyping. Focused on creating thoughtful, accessible digital experiences.' : 'Product designer focused on thoughtful, accessible digital experiences. Turning research into clear interfaces and interactive prototypes.', 12, 'Regular', C.muted, 464), txt('EXPERIENCE', 10, 'Bold', C.green), txt('Product Designer · Studio North', 13, 'Semi Bold'), txt('2023 — Present', 11, 'Regular', C.muted), txt('• Designed onboarding flows for a student learning app.\n• Interviewed eight students and built Figma prototypes.', 12, 'Regular', C.muted, 464), txt('SKILLS', 10, 'Bold', C.green), txt('Figma · User research · Prototyping · Design systems', 12, 'Regular', C.muted, 464), txt('EDUCATION', 10, 'Bold', C.green), txt('BS Communication Design · 2023', 13, 'Semi Bold'));
    add(stage, paper);
    add(column, stage, txt('Your changes appear here as you edit.', 11, 'Regular', C.muted, 568));
    return column;
}
function profileBody() { const editor = frame('Editor', 560, 'VERTICAL', undefined, 0, 18); const a = card('Personal details', 560); add(a, txt('Let’s start with you', 20, 'Semi Bold'), txt('The essentials. Nothing more than you need.', 12, 'Regular', C.muted), row('Identity fields', 516, [field('Full name *', 'Ayesha Khan', 250), field('Email address *', 'ayesha.khan@example.com', 250)], 16), row('Role fields', 516, [field('Location', 'Lahore, Pakistan', 250), field('Target role *', 'Product Designer', 250)], 16), field('Career goal', 'Create thoughtful, accessible digital experiences for people.', 516, true)); const b = card('Experience details', 560); add(b, txt('The experience you bring', 20, 'Semi Bold'), row('Job details', 516, [field('Company or project', 'Studio North', 250), field('Dates', '2023 — Present', 250)], 16), field('What did you do?', 'Designed onboarding flows. Interviewed eight students and built Figma prototypes.', 516, true), field('Skills', 'Figma, User research, Prototyping, Design systems', 516), field('Education', 'BS Communication Design · 2023', 516), button('Choose my template →', 'Forma', 'R2')); add(editor, a, b); return editor; }
function tinyTemplate(name, selected, to) { const c = card('Template / ' + name, 162, selected ? C.greenSoft : '#F9FAF8', 10, 12); c.strokes = [fill(selected ? C.green : C.line)]; c.strokeWeight = selected ? 2 : 1; const sheet = frame('Resume thumbnail', 140, 'VERTICAL', C.white, 12, 7, 155); add(sheet, txt('Ayesha Khan', 12, 'Semi Bold', C.green, 116), txt('Product Designer', 8, 'Regular', C.muted, 116), rule(116), txt('PROFILE', 7, 'Bold', C.green), txt('Thoughtful experiences.\nClear, focused design.', 8, 'Regular', C.muted, 116), txt('EXPERIENCE', 7, 'Bold', C.green), rule(116), rule(92)); add(c, sheet, txt(name + (selected ? '  ✓' : ''), 13, 'Semi Bold'), txt('Clear & professional', 10, 'Regular', C.muted)); return bind(c, to); }
function templatesBody(classic) { const c = card('Template selection', 560); add(c, txt('Find your style', 20, 'Semi Bold'), txt('Choose a layout. Preview it instantly.', 13, 'Regular', C.muted), row('Template options', 516, [tinyTemplate('Evergreen', !classic, 'R2'), tinyTemplate('Editorial', classic, 'R3'), tinyTemplate('Studio', false, 'R8')], 15), txt('A touch of color', 15, 'Semi Bold'), row('Color choices', 516, [pill('Forest', 'Forma'), pill('Slate blue', 'Quest'), pill('Terracotta', 'Forma')], 12), txt('Simple headings, clear reading order, and plenty of space for your experience.', 12, 'Regular', C.muted, 516), button('Refine with AI →', 'Forma', 'R4')); return c; }
function aiBody(applied) {
    const col = frame('Editor', 560, 'VERTICAL', undefined, 0, 16);
    const intro = card('AI introduction', 560, C.greenSoft);
    add(intro, pill('AI writing assistant · demo'), txt('Your experience. A little clearer.', 20, 'Semi Bold'), txt('Suggestions use your own details. Review every draft before keeping it.', 13, 'Regular', C.muted, 516), button('Refresh suggestions ✦', 'Forma', 'R4'));
    add(col, intro);
    const entries = [['Professional summary', 'Product Designer with skills in Figma, user research, and prototyping. Focused on creating thoughtful, accessible digital experiences.'], ['Experience, easy to scan', 'Designed onboarding flows for a student learning app.\nInterviewed eight students and built Figma prototypes.'], ['Your skills, clearly organized', 'Figma · User research · Prototyping · Design systems']];
    entries.forEach(([title, value]) => { const c = card('Suggestion / ' + title, 560); add(c, txt(title, 16, 'Semi Bold'), txt(value, 13, 'Regular', C.muted, 516), button(applied ? '✓ Applied to resume' : 'Apply suggestion', 'Forma', applied ? 'R4' : 'R5', applied)); add(col, c); });
    add(col, row('Editor actions', 560, [button('Undo change', 'Forma', 'R4', true), button('Review & export →', 'Forma', 'R6')], 16));
    return col;
}
function exportBody(success) { const c = card(success ? 'Download success' : 'Export options', 560); if (success) {
    add(c, pill('✓ DOWNLOAD READY'), txt('Your next chapter is ready.', 26, 'Semi Bold', C.ink, 516), txt('In this Figma prototype, the download flow is simulated. Open the browser prototype for a real PDF or DOCX file.', 14, 'Regular', C.muted, 516), button('Keep editing →', 'Forma', 'R1'), button('Back to exports', 'Forma', 'R6', true));
    return c;
} add(c, txt('Your resume, ready to go.', 22, 'Semi Bold'), txt('Choose the format that works for your next step.', 13, 'Regular', C.muted, 516)); for (const format of ['PDF', 'DOCX']) {
    const box = card('Export / ' + format, 516, '#FAFBF9', 18, 12);
    add(box, pill(format), txt(format === 'PDF' ? 'Ready to send' : 'Easy to edit', 17, 'Semi Bold'), txt(format === 'PDF' ? 'A polished document for sharing.' : 'An editable Word document.', 12, 'Regular', C.muted), button('Download ' + format + ' ↓', 'Forma', 'R7', format === 'DOCX'));
    add(c, box);
} add(c, txt('One last look', 16, 'Semi Bold'), txt('✓ Check contact details and dates.\n✓ Keep every claim accurate.\n✓ Match your experience to the role.', 13, 'Regular', C.muted, 516), button('Make a final edit', 'Forma', 'R1', true)); return c; }
function makeResume() {
    const definitions = [['R1', 'Your next chapter starts here.', 'A few details about you. We’ll take care of the structure.', 0, profileBody, 'Evergreen', false], ['R2', 'A good first impression.', 'Choose a style that feels like you.', 1, () => templatesBody(false), 'Evergreen', false], ['R3', 'A good first impression.', 'Editorial: a timeless, focused layout.', 1, () => templatesBody(true), 'Editorial', false], ['R4', 'Your experience. A little clearer.', 'Review every draft and keep what sounds like you.', 2, () => aiBody(false), 'Evergreen', false], ['R5', 'Your experience. A little clearer.', 'Your suggestions are now in the live preview.', 2, () => aiBody(true), 'Evergreen', true], ['R6', 'Ready for your next opportunity.', 'Take one last look, then make your next move.', 3, () => exportBody(false), 'Evergreen', true], ['R7', 'You’re ready for the next chapter.', 'A completed export flow.', 3, () => exportBody(true), 'Evergreen', true], ['R8', 'A good first impression.', 'Studio: a fresh, expressive layout.', 1, () => templatesBody(false), 'Studio', false]];
    definitions.forEach(([id, title, sub, n, body, template, applied]) => { const { main } = shell(id, title, sub, 'Forma', n); add(main, row('Editor and live preview', 1152, [body(), resumePreview(template, applied)], 24)); });
}
function art(width, bg = '#DCEAE5') { const f = frame('Course illustration', width, 'HORIZONTAL', bg, 18, 0, 128); f.cornerRadius = 10; f.primaryAxisAlignItems = 'CENTER'; f.counterAxisAlignItems = 'CENTER'; const window = card('Interface sketch', 100, C.white, 10, 7); window.rotation = -6; add(window, txt('• • •', 9, 'Bold', '#A1B5A8'), rule(80), row('Tiles', 80, [frame('Tile', 36, 'VERTICAL', '#B4CCBE', 0, 0, 22), frame('Tile', 36, 'VERTICAL', '#DCE9E0', 0, 0, 22)], 8), row('Tiles', 80, [frame('Tile', 36, 'VERTICAL', '#DCE9E0', 0, 0, 22), frame('Tile', 36, 'VERTICAL', '#DCE9E0', 0, 0, 22)], 8)); add(f, window); return f; }
function courseTile(title, category, bg, to, width = 388) { const c = card('Course / ' + title, width, C.white, 16, 12); add(c, art(width - 32, bg), pill(category + ' · Beginner', 'Quest'), txt(title, 17, 'Semi Bold', C.ink, width - 32), txt('12 lessons  ·  3h 20m', 12, 'Regular', C.muted), button('Explore course →', 'Quest', to, true)); return c; }
function asideQuest(updated = false) { const col = frame('Right rail', 328, 'VERTICAL', undefined, 0, 18); const streak = card('Daily streak', 328); add(streak, txt(`${updated ? 7 : 6} days of showing up`, 17, 'Semi Bold'), txt('One small step keeps your streak alive.', 12, 'Regular', C.muted, 284), txt(updated ? '✓   ✓   ✓   ✓   ✓   ✓   ✓' : '✓   ✓   ✓   ✓   ✓   ✓   ○', 23, 'Semi Bold', '#C69C4E'), txt('F     S     S     M     T     W     T', 11, 'Regular', C.muted)); const challenge = card('Daily challenge', 328, '#FBF8EF'); add(challenge, txt('TODAY’S SMALL CHALLENGE', 10, 'Bold', '#B08D46'), txt(updated ? 'A little more confidence.' : 'Think in components.', 18, 'Semi Bold'), txt('A quick design question. A little progress.', 12, 'Regular', C.muted, 284), pill('+50 XP', 'Quest'), button(updated ? 'Review answer →' : 'Take challenge →', 'Quest', 'L4', true)); const leader = card('Weekly leaderboard', 328); add(leader, txt('This week’s explorers', 17, 'Semi Bold')); [['1', 'Mia Wilson', '1,490'], ['2', 'Omar Hassan', '1,435'], ['3', updated ? 'You' : 'Sophie Chen', updated ? '1,430' : '1,360'], ['4', updated ? 'Sophie Chen' : 'You', updated ? '1,360' : '1,280']].forEach(([rank, name, xp]) => add(leader, row('Learner / ' + name, 284, [txt(rank, 12, 'Regular', C.muted, 18), txt(name, 12, 'Semi Bold', C.ink, 155), txt(xp + ' XP', 11, 'Regular', C.muted, 87)], 8))); add(leader, button('View leaderboard →', 'Quest', 'L6', true)); const badges = card('Achievements preview', 328); add(badges, txt('Little wins, well earned.', 16, 'Semi Bold'), txt('✦        ◈        ' + (updated ? '★' : '○'), 32, 'Bold', '#B595D4'), button('View achievements →', 'Quest', 'L7', true)); add(col, streak, challenge, leader, badges); return col; }
function overview(updated = false) {
    const left = frame('Learning overview', 800, 'VERTICAL', undefined, 0, 20);
    const hero = card('Momentum hero', 800, '#EEE7FC', 28, 13);
    add(hero, txt('YOUR CURIOSITY. YOUR NEXT CHAPTER.', 10, 'Bold', '#9274BB'), row('Hero content', 744, [add(frame('Hero copy', 600, 'VERTICAL', undefined, 0, 12), txt('A little better. Every single day.', 29, 'Semi Bold', '#493268', 600), txt('You’re building more than skills. You’re building a habit that takes you places.', 13, 'Regular', '#857391', 600), button('Keep the momentum →', 'Quest', 'L3')), txt('✦', 95, 'Bold', '#9C78DC')], 18));
    add(left, hero);
    const stats = row('Learning statistics', 800, [], 16);
    [[updated ? '21' : '20', 'Lessons completed'], [updated ? '1,430' : '1,280', 'Total XP earned'], [updated ? '5' : '2', 'Badges unlocked']].forEach(([v, label]) => { const c = card('Stat / ' + label, 256, C.white, 20, 6); add(c, txt(v, 25, 'Semi Bold'), txt(label, 11, 'Regular', C.muted)); add(stats, c); });
    add(left, stats, txt('Pick up where you left off', 19, 'Semi Bold'));
    const course = card('Continue learning', 800);
    add(course, row('Active course content', 756, [art(150), add(frame('Active course details', 584, 'VERTICAL', undefined, 0, 10), pill('Design · Beginner', 'Quest'), txt('UI design fundamentals', 19, 'Semi Bold'), txt(`${updated ? 7 : 6} of 12 lessons completed`, 12, 'Regular', C.muted), progress(584, updated ? 7 / 12 : .5, 'Quest'), button('▷ Continue learning', 'Quest', 'L3'))], 22));
    add(left, course, txt('A good next step for you', 19, 'Semi Bold'), row('Recommended courses', 800, [courseTile('Build better with Figma', 'Design', '#F6E6D9', 'L2'), courseTile('Your first responsive website', 'Development', '#E0ECF7', 'L2')], 24));
    return left;
}
function makeLearning() {
    let s = shell('L1', 'Good to see you, Ayesha ☀', 'Big goals start with small steps. Let’s take the next one.', 'Quest');
    add(s.main, row('Dashboard content', 1152, [overview(), asideQuest()], 24));
    s = shell('L8', 'Look at you, moving forward.', 'Your progress, streak, and leaderboard are up to date.', 'Quest');
    add(s.main, row('Dashboard content', 1152, [overview(true), asideQuest(true)], 24));
    s = shell('L2', 'Make space for something new.', 'Follow your curiosity, or keep building on what you know.', 'Quest', 1);
    add(s.main, row('Course filters', 1152, [pill('All courses', 'Quest'), pill('In progress', 'Quest'), pill('Design', 'Quest'), pill('Research', 'Quest')], 12));
    add(s.main, row('Course library first row', 1152, [courseTile('UI design fundamentals', 'Design', '#DCEAE5', 'L3', 368), courseTile('Understand your users', 'Research', '#EAE3F8', 'L3', 368), courseTile('Build better with Figma', 'Design', '#F6E6D9', 'L3', 368)], 24));
    add(s.main, row('Course library second row', 1152, [courseTile('Your first responsive website', 'Development', '#E0ECF7', 'L3', 368), courseTile('Design for everyone', 'Design', '#DCEAE5', 'L3', 368)], 24));
    s = shell('L3', 'Designing with components', 'UI design fundamentals · Lesson 7 of 12', 'Quest', 1);
    const lesson = card('Lesson content', 800);
    const illustration = frame('Button component demo', 756, 'HORIZONTAL', C.purpleSoft, 35, 15, 200);
    illustration.counterAxisAlignItems = 'CENTER';
    illustration.primaryAxisAlignItems = 'CENTER';
    add(illustration, button('Continue', 'Quest', 'L5'), button('Go back', 'Quest', 'L1', true), components['Quest/Primary/Disabled'].createInstance());
    add(lesson, illustration, pill('8-minute practice lesson', 'Quest'), txt('One source. A consistent experience.', 24, 'Semi Bold'), txt('A component is a reusable piece of an interface. A good button, input, or navigation item behaves consistently wherever it appears.', 16, 'Regular', C.muted, 756), txt('• Give every component a clear purpose.\n• Use variants for default, hover, and disabled states.\n• Keep spacing and typography consistent.', 15, 'Regular', C.muted, 756), txt('Try it: find a repeated pattern in an app you use. Describe its purpose and one state it needs.', 14, 'Regular', C.muted, 756), button('✓ Mark lesson complete · +100 XP', 'Quest', 'L5'));
    const path = card('Learning path', 328);
    add(path, txt('Your learning path', 18, 'Semi Bold'), txt('▷ Designing with components\n\n○ Build a clear visual hierarchy\n\n○ Make room for every screen\n\n○ Design feedback that helps\n\n○ Prototype a complete journey', 13, 'Regular', C.muted, 284));
    add(s.main, row('Lesson layout', 1152, [lesson, path], 24));
    s = shell('L4', 'Today’s small challenge', 'One question. A little more confidence.', 'Quest');
    const quiz = card('Challenge card', 760, C.white, 32, 20);
    add(quiz, pill('DAILY CHALLENGE · 50 XP', 'Quest'), txt('Think in components.', 29, 'Semi Bold'), txt('Several screens use the same button. What is the best way to keep them consistent as your design changes?', 17, 'Regular', C.muted, 696));
    [['Copy and edit each button separately', 'L9'], ['Use a reusable component with variants', 'L10'], ['Replace all buttons with screenshots', 'L9']].forEach(([label, to]) => { const option = card('Answer / ' + label, 696, C.white, 17, 0); add(option, txt('○  ' + label, 14, 'Regular', C.ink, 662)); bind(option, to); add(quiz, option); });
    add(quiz, txt('Choose an answer to check it.', 12, 'Regular', C.muted), button('Back to overview', 'Quest', 'L1', true));
    add(s.main, quiz);
    s = shell('L9', 'A good question is a chance to grow.', 'Try the challenge again.', 'Quest');
    const retry = card('Challenge feedback', 760, C.white, 32, 18);
    add(retry, pill('NOT QUITE — TRY AGAIN', 'Quest'), txt('Think about a single reusable source.', 27, 'Semi Bold', C.ink, 696), txt('Copying each button creates separate objects to maintain. A reusable component lets one change reach every instance.', 16, 'Regular', C.muted, 696), button('Try again →', 'Quest', 'L4'));
    add(s.main, retry);
    for (const [id, title, reward, body] of [['L5', 'Look at you, moving forward.', '+100 XP', 'Another lesson in the books. You’ve completed 7 of 12 lessons and kept your streak alive.'], ['L10', 'Challenge accepted. Nicely done.', '+50 XP', 'Correct! Components share a consistent structure; variants express their different states.']]) {
        s = shell(id, 'Progress worth celebrating.', 'Keep the momentum. Every small step counts.', 'Quest');
        const rewardCard = card('Reward celebration', 760, C.purpleSoft, 40, 20);
        rewardCard.counterAxisAlignItems = 'CENTER';
        add(rewardCard, txt('✦', 75, 'Bold', C.purple), txt(title, 29, 'Semi Bold', C.ink, 680), txt(body, 16, 'Regular', C.muted, 680), txt(reward, 42, 'Bold', C.purple), button('Back to overview →', 'Quest', 'L8'), button('View achievements', 'Quest', 'L7', true));
        add(s.main, rewardCard);
    }
    s = shell('L6', 'A little friendly momentum.', 'Celebrate your progress alongside other curious minds.', 'Quest', 2);
    const ranking = card('Leaderboard', 1152);
    add(ranking, row('Leaderboard headings', 1108, [txt('RANK', 11, 'Bold', C.muted, 80), txt('LEARNER', 11, 'Bold', C.muted, 680), txt('XP EARNED', 11, 'Bold', C.muted, 280)], 24));
    [['1', 'Mia Wilson', '1,490'], ['2', 'Omar Hassan', '1,435'], ['3', 'Ayesha Khan (you)', '1,430'], ['4', 'Sophie Chen', '1,360'], ['5', 'Liam Park', '1,195']].forEach(([rank, name, xp]) => { const r = frame('Rank / ' + name, 1108, 'HORIZONTAL', name.includes('you') ? C.purpleSoft : undefined, 16, 24, 76); r.cornerRadius = 9; r.counterAxisAlignItems = 'CENTER'; add(r, txt(rank, 16, 'Semi Bold', C.muted, 48), txt(name, 16, 'Semi Bold', C.ink, 680), txt(xp + ' XP', 15, 'Regular', C.purple, 270)); add(ranking, r); });
    add(s.main, ranking, txt('Demo rankings. Your progress is personal; this is a little friendly motivation.', 13, 'Regular', C.muted));
    s = shell('L7', 'Every little win counts.', 'Each badge tells a part of your story.', 'Quest', 3);
    const names = ['First steps', 'Curious mind', 'Week warrior', 'Component thinker', 'Course champion', 'Challenge accepted'];
    for (let i = 0; i < 2; i++) {
        const line = row('Achievement row', 1152, [], 24);
        for (let j = 0; j < 3; j++) {
            const name = names[i * 3 + j], unlocked = name !== 'Course champion', b = card('Achievement / ' + name, 368, C.white, 28, 16);
            b.counterAxisAlignItems = 'CENTER';
            const instance = components['Badge/' + (unlocked ? 'Unlocked' : 'Locked')].createInstance();
            instance.findAll(n => n.type === 'TEXT').find(n => n.characters === 'Week warrior').characters = name;
            add(b, instance, txt(name, 19, 'Semi Bold'), txt(unlocked ? 'A milestone you have earned.' : 'Finish another course to unlock.', 13, 'Regular', C.muted), pill(unlocked ? 'Unlocked' : 'Keep exploring', 'Quest'));
            add(line, b);
        }
        add(s.main, line);
    }
}
function makeMobile() {
    const r = frame('M1 / Forma mobile', 390, 'VERTICAL', C.bg, 20, 22, 1280);
    page.appendChild(r);
    roots.M1 = r;
    add(r, row('Mobile header', 350, [txt('☰   forma', 25, 'Bold', C.green), txt('Saved', 11, 'Regular', C.muted)], 165), txt('Your next chapter\nstarts here.', 28, 'Semi Bold', C.ink, 350), txt('Step 1 of 4 · Your profile', 12, 'Regular', C.muted));
    const panel = card('Mobile profile', 350, C.white, 20, 16);
    add(panel, txt('Let’s start with you', 20, 'Semi Bold'), field('Full name *', 'Ayesha Khan', 310), field('Email address *', 'ayesha.khan@example.com', 310), field('Location', 'Lahore, Pakistan', 310), field('Target role *', 'Product Designer', 310), field('Career goal', 'Create thoughtful, accessible digital experiences.', 310, true), button('Choose my template →', 'Forma', 'R2', false, 310));
    add(r, panel, txt('Live preview', 15, 'Semi Bold'));
    const paper = card('Mobile resume preview', 350);
    add(paper, txt('Ayesha Khan', 27, 'Semi Bold', C.green), txt('Product Designer', 13, 'Regular', C.muted), rule(306), txt('PROFILE', 10, 'Bold', C.green), txt('Thoughtful, accessible digital experiences. Clear interfaces and interactive prototypes.', 13, 'Regular', C.muted, 306));
    add(r, paper);
    const l = frame('M2 / Quest mobile', 390, 'VERTICAL', C.bg, 20, 20, 1280);
    page.appendChild(l);
    roots.M2 = l;
    add(l, row('Mobile header', 350, [txt('☰   quest', 25, 'Bold', C.purple), pill('6 day streak', 'Quest')], 91), txt('Good to see you,\nAyesha ☀', 29, 'Semi Bold', C.ink, 350), txt('Big goals start with small steps.', 13, 'Regular', C.muted));
    const hero = card('Mobile momentum', 350, '#EEE7FC', 23, 14);
    add(hero, txt('A little better.\nEvery single day.', 27, 'Semi Bold', '#493268', 304), txt('You’re building a habit that takes you places.', 13, 'Regular', C.muted, 304), button('Keep the momentum →', 'Quest', 'L3'));
    add(l, hero, row('Mobile stats', 350, [pill('20 lessons', 'Quest'), pill('1,280 XP', 'Quest'), pill('2 badges', 'Quest')], 8), txt('Pick up where you left off', 19, 'Semi Bold'), courseTile('UI design fundamentals', 'Design', '#DCEAE5', 'L3', 350), button('Take today’s challenge · +50 XP', 'Quest', 'L4', true, 350), button('View achievements →', 'Quest', 'L7', true, 350));
}
async function run() {
    try {
        for (const style of ['Regular', 'Semi Bold', 'Bold'])
            await figma.loadFontAsync({ family: font, style });
    }
    catch (_a) {
        font = 'Roboto';
        for (const style of ['Regular', 'Semi Bold', 'Bold'])
            await figma.loadFontAsync({ family: font, style: style === 'Semi Bold' ? 'Medium' : style });
    }
    // Inter is available by default in Figma. Fail clearly if the fallback lacks the requested style.
    if (font === 'Roboto') {
        figma.closePlugin('Inter fonts are unavailable. Enable Inter in Figma and run the generator again. No existing layers were changed.');
        return;
    }
    page = figma.createPage();
    page.name = 'Forma + Quest · Interactive prototypes';
    await figma.setCurrentPageAsync(page);
    page.backgrounds = [fill('#ECEEF0')];
    await makeComponents();
    makeResume();
    makeLearning();
    makeMobile();
    const resumeIds = ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8'];
    resumeIds.forEach((id, i) => { roots[id].x = (i % 4) * 1520; roots[id].y = Math.floor(i / 4) * 1560; roots[id].name = `Forma / ${id} / ${['Profile setup', 'Evergreen template', 'Editorial template', 'AI suggestions', 'Suggestions applied', 'Review and export', 'Export success', 'Studio template'][i]}`; });
    const learningIds = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'L7', 'L8', 'L9', 'L10'];
    learningIds.forEach((id, i) => { roots[id].x = (i % 4) * 1520; roots[id].y = 3240 + Math.floor(i / 4) * 1560; roots[id].name = `Quest / ${id} / ${['Dashboard', 'Course library', 'Lesson', 'Daily challenge', 'Lesson reward', 'Leaderboard', 'Achievements', 'Updated dashboard', 'Challenge retry', 'Challenge reward'][i]}`; });
    roots.M1.x = 6300;
    roots.M1.y = 0;
    roots.M2.x = 6750;
    roots.M2.y = 0;
    for (const route of routes) {
        if (!roots[route.to])
            throw new Error('Unknown destination ' + route.to);
        await route.node.setReactionsAsync([{ trigger: { type: 'ON_CLICK' }, actions: [{ type: 'NODE', destinationId: roots[route.to].id, navigation: 'NAVIGATE', transition, resetScrollPosition: true }] }]);
    }
    page.flowStartingPoints = [{ nodeId: roots.R1.id, name: 'Forma · Build a resume' }, { nodeId: roots.L1.id, name: 'Quest · Your learning journey' }, { nodeId: roots.M1.id, name: 'Mobile · Forma' }, { nodeId: roots.M2.id, name: 'Mobile · Quest' }];
    page.selection = [roots.R1, roots.L1];
    figma.viewport.scrollAndZoomIntoView([roots.R1]);
    figma.closePlugin(`Created 20 editable screens, 3 component sets, and ${routes.length} prototype connections. Select a flow and press Present.`);
}
run().catch(error => { console.error(error); figma.closePlugin('Could not finish: ' + String(error) + '. Existing content was preserved; any new layers remain on the generated page.'); });
